import os, subprocess, sys, html
from common import BASE, font_css, all_episodes, fa, SEASONS
from scenes import scene_svg

OUT = os.path.join(BASE, 'out', 'THE_LAST_CODE_OF_KHORASAN')
TMP = os.path.join(BASE, 'tmp_posters')
os.makedirs(os.path.join(OUT, 'Posters'), exist_ok=True)
os.makedirs(TMP, exist_ok=True)
PHOTO = 'file://' + os.path.join(BASE, 'ref_photo.png')

# face centre in source photo (941x1672)
FX, FY = 470, 560
# per-episode portrait: (box_left, box_top, box_w, box_h, scale, face_x_in_box, face_y_in_box, tint, opacity)
P = {
 1: (560, 120, 640, 900, 0.95, 330, 430, 'gold', .85),
 2: (300, 180, 600, 800, 1.25, 300, 420, 'emerald', .9),
 3: (0, 80, 700, 860, 0.85, 380, 440, 'natural', .9),
 4: (350, 60, 500, 640, 0.75, 250, 330, 'gold', .8),
 5: (500, 100, 700, 820, 1.05, 380, 430, 'emerald', .85),
 6: (0, 140, 640, 760, 0.8, 300, 400, 'natural', .8),
 7: (620, 120, 580, 760, 0.9, 260, 420, 'gold', .85),
 8: (280, 40, 640, 780, 1.4, 320, 420, 'emerald', .75),
 9: (360, 120, 480, 680, 1.1, 240, 380, 'red', .9),
 10: (0, 60, 620, 820, 1.0, 340, 430, 'natural', .85),
 11: (580, 60, 620, 780, 0.85, 300, 420, 'gold', .85),
 12: (160, 100, 880, 760, 1.6, 440, 420, 'emerald', .7),
 13: (380, 60, 440, 660, 0.7, 220, 360, 'natural', .9),
 14: (300, 80, 600, 760, 1.0, 300, 420, 'gold', .85),
 15: (620, 160, 580, 700, 0.8, 300, 380, 'emerald', .9),
 16: (240, 40, 720, 900, 1.15, 360, 460, 'natural', .9),
}
TINT = {
 'gold': 'grayscale(1) sepia(1) saturate(1.7) brightness(1.0) contrast(1.15)',
 'emerald': 'grayscale(1) sepia(1) hue-rotate(110deg) saturate(2.6) brightness(.95) contrast(1.15)',
 'natural': 'contrast(1.08) saturate(.9)',
 'red': 'grayscale(1) sepia(1) hue-rotate(-30deg) saturate(3) brightness(.9) contrast(1.2)',
}

CSS = font_css() + '''
*{margin:0;padding:0;box-sizing:border-box}
html,body{width:1200px;height:1800px;background:#000;overflow:hidden}
.poster{position:relative;width:1200px;height:1800px;overflow:hidden;background:#000}
.scene{position:absolute;inset:0}
.portrait{position:absolute;background-repeat:no-repeat;
  -webkit-mask-image:radial-gradient(ellipse 44% 47% at 50% 45%,#000 48%,transparent 100%);
  mask-image:radial-gradient(ellipse 44% 47% at 50% 45%,#000 48%,transparent 100%)}
.shade{position:absolute;left:0;right:0;bottom:0;height:820px;background:linear-gradient(to bottom,rgba(0,0,0,0),rgba(0,0,0,.82) 38%,rgba(0,0,0,.97))}
.topshade{position:absolute;left:0;right:0;top:0;height:260px;background:linear-gradient(to top,rgba(0,0,0,0),rgba(0,0,0,.85))}
.frame{position:absolute;inset:28px;border:1.5px solid rgba(217,180,90,.55)}
.frame:after{content:"";position:absolute;inset:8px;border:1px solid rgba(217,180,90,.22)}
.top{position:absolute;top:62px;left:0;right:0;text-align:center}
.en{font-family:Cinzel;font-weight:700;font-size:34px;letter-spacing:11px;color:#e6c574}
.fa-series{font-family:Vazirmatn;font-weight:500;font-size:26px;color:#cfe9df;margin-top:10px;direction:rtl;letter-spacing:1px}
.bottom{position:absolute;left:80px;right:80px;bottom:90px;text-align:center;direction:rtl}
.ep{font-family:Vazirmatn;font-weight:600;font-size:28px;color:#38d39f;letter-spacing:2px}
.ep span{color:#d9b45a;margin:0 14px}
.title{font-family:Vazirmatn;font-weight:900;font-size:108px;line-height:1.25;margin-top:14px;
  background:linear-gradient(180deg,#fff3c9 0%,#e6c574 45%,#9a7428 100%);-webkit-background-clip:text;background-clip:text;color:transparent;
  filter:drop-shadow(0 6px 18px rgba(0,0,0,.9))}
.title.long{font-size:84px}
.rule{width:340px;height:2px;margin:26px auto 24px;background:linear-gradient(90deg,transparent,#d9b45a,transparent)}
.tag{font-family:Naskh;font-weight:400;font-size:36px;line-height:1.7;color:#f2ead2}
.author{margin-top:34px;font-family:Vazirmatn;font-weight:400;font-size:25px;color:#bfae7a;letter-spacing:1px}
.author b{font-weight:700;color:#e6c574}
'''

def poster_html(ep):
    n = ep['n']
    bl, bt, bw, bh, s, fx, fy, tint, op = P[n]
    pw = 941 * s
    bx = fx - FX * s; by = fy - FY * s
    title = ep['title']
    long = ' long' if len(title) > 14 else ''
    sname = SEASONS[ep['season']][1]
    return f'''<!doctype html><html lang="fa"><head><meta charset="utf-8"><style>{CSS}</style></head><body>
<div class="poster">
 <div class="scene">{scene_svg(n)}</div>
 <div class="portrait" style="left:{bl}px;top:{bt}px;width:{bw}px;height:{bh}px;background-image:url('{PHOTO}');background-size:{pw:.0f}px auto;background-position:{bx:.0f}px {by:.0f}px;filter:{TINT[tint]};opacity:{op}"></div>
 <div class="topshade"></div><div class="shade"></div><div class="frame"></div>
 <div class="top"><div class="en">THE LAST CODE OF KHORASAN</div><div class="fa-series">آخرین کُد خراسان</div></div>
 <div class="bottom">
  <div class="ep">{sname} — {html.escape(SEASONS[ep['season']][0])}<span>|</span>قسمت {fa(n)}</div>
  <div class="title{long}">{html.escape(title)}</div>
  <div class="rule"></div>
  <div class="tag">{html.escape(ep['tagline'])}</div>
  <div class="author">نویسنده: <b>وکیل احمد حیدری</b></div>
 </div>
</div></body></html>'''

def cover_html():
    return f'''<!doctype html><html lang="fa"><head><meta charset="utf-8"><style>{CSS}
.full{{position:absolute;left:-40px;top:-60px;width:1280px;height:2274px;background:url('{PHOTO}') center top/1280px auto no-repeat;filter:contrast(1.08) saturate(.85) brightness(.92)}}
.tintE{{position:absolute;inset:0;background:radial-gradient(ellipse at 50% 35%,rgba(15,138,99,0) 30%,rgba(6,40,29,.65) 100%);mix-blend-mode:multiply}}
.big{{font-family:Vazirmatn;font-weight:900;font-size:150px;line-height:1.15;background:linear-gradient(180deg,#fff3c9,#e6c574 50%,#9a7428);-webkit-background-clip:text;background-clip:text;color:transparent;filter:drop-shadow(0 8px 24px #000)}}
.en2{{font-family:Cinzel;font-weight:700;font-size:46px;letter-spacing:14px;color:#e6c574;margin-top:6px}}
.sub{{font-family:Vazirmatn;font-weight:500;font-size:30px;color:#38d39f;margin-top:26px;letter-spacing:1px}}
.code{{position:absolute;top:70px;left:0;right:0;text-align:center;font-family:monospace;font-size:22px;letter-spacing:6px;color:rgba(56,211,159,.75)}}
</style></head><body><div class="poster">
<div class="full"></div><div class="tintE"></div>
<div class="topshade"></div><div class="shade" style="height:900px"></div><div class="frame"></div>
<div class="code">&lt;/ KHORASAN &gt; · 3 SEASONS · 16 EPISODES</div>
<div class="bottom" style="bottom:100px">
 <div class="big">آخرین کُد خراسان</div>
 <div class="en2">THE LAST CODE OF KHORASAN</div>
 <div class="rule"></div>
 <div class="tag">کتاب سینمایی در سه فصل و شانزده قسمت</div>
 <div class="sub">درام زندگی‌نامه‌ای · فناوری · فلسفی · اجتماعی</div>
 <div class="author" style="font-size:32px">نویسنده: <b>وکیل احمد حیدری</b></div>
</div></div></body></html>'''

def render(html_text, name, out_png):
    hp = os.path.join(TMP, name + '.html')
    open(hp, 'w', encoding='utf-8').write(html_text)
    cmd = ['google-chrome', '--headless=new', '--no-sandbox', '--disable-gpu', '--hide-scrollbars',
           '--allow-file-access-from-files', '--force-device-scale-factor=2', '--window-size=1200,1800',
           '--virtual-time-budget=4000', f'--screenshot={out_png}', 'file://' + hp]
    subprocess.run(cmd, check=True, capture_output=True)

if __name__ == '__main__':
    only = [int(a) for a in sys.argv[1:]] if len(sys.argv) > 1 else None
    if not only or 0 in only:
        render(cover_html(), 'cover', os.path.join(OUT, 'Main_Cover.png'))
        print('cover')
    for ep in all_episodes():
        if only and ep['n'] not in only:
            continue
        render(poster_html(ep), f'p{ep["n"]:02d}', os.path.join(OUT, 'Posters', f'Poster_{ep["n"]:02d}.png'))
        print('poster', ep['n'])
