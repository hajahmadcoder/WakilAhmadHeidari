"""Procedural SVG background scenes for each episode poster (1200x1800)."""
import random, math

W, H = 1200, 1800
G = '#d9b45a'      # gold
GL = '#f4dd9a'     # light gold
E = '#0f8a63'      # emerald
EL = '#38d39f'     # light emerald
ED = '#06281d'     # deep emerald
K = '#030605'      # near black

DEFS = f'''
<defs>
 <linearGradient id="sky" x1="0" y1="0" x2="0" y2="1">
  <stop offset="0" stop-color="#010302"/><stop offset=".55" stop-color="{ED}"/><stop offset="1" stop-color="#010302"/>
 </linearGradient>
 <radialGradient id="sun" cx=".5" cy=".5" r=".5">
  <stop offset="0" stop-color="{GL}" stop-opacity="1"/><stop offset=".35" stop-color="{G}" stop-opacity=".55"/><stop offset="1" stop-color="{G}" stop-opacity="0"/>
 </radialGradient>
 <radialGradient id="glowE" cx=".5" cy=".5" r=".5">
  <stop offset="0" stop-color="{EL}" stop-opacity=".9"/><stop offset="1" stop-color="{E}" stop-opacity="0"/>
 </radialGradient>
 <radialGradient id="glowR" cx=".5" cy=".5" r=".5">
  <stop offset="0" stop-color="#ff4a3d" stop-opacity=".9"/><stop offset="1" stop-color="#7a0d0d" stop-opacity="0"/>
 </radialGradient>
 <linearGradient id="goldv" x1="0" y1="0" x2="0" y2="1">
  <stop offset="0" stop-color="{GL}"/><stop offset="1" stop-color="#8a6a22"/>
 </linearGradient>
 <filter id="blur8"><feGaussianBlur stdDeviation="8"/></filter>
 <filter id="blur3"><feGaussianBlur stdDeviation="3"/></filter>
 <filter id="blur30"><feGaussianBlur stdDeviation="30"/></filter>
</defs>'''

def rng(n):
    return random.Random(1000 + n)

def stars(r, count=140, ymax=900, color='#ffffff'):
    s = []
    for _ in range(count):
        x, y = r.uniform(0, W), r.uniform(0, ymax)
        rad = r.choice([0.6, 0.8, 1.0, 1.4, 2.0])
        op = r.uniform(.25, .9)
        s.append(f'<circle cx="{x:.0f}" cy="{y:.0f}" r="{rad}" fill="{color}" opacity="{op:.2f}"/>')
    return ''.join(s)

def ridge(r, base, amp, rough, color, op=1, step=40):
    pts = [(0, H)]
    y = base
    for x in range(0, W + step, step):
        y = base - amp * (0.5 + 0.5 * math.sin(x / 210 + r.uniform(0, .6))) - r.uniform(0, rough)
        pts.append((x, y))
    pts.append((W, H))
    d = 'M' + ' L'.join(f'{x:.0f},{y:.0f}' for x, y in pts) + ' Z'
    return f'<path d="{d}" fill="{color}" opacity="{op}"/>'

def peaks(r, base, n, hmin, hmax, color, op=1, snow=False):
    """Jagged mountain range built from overlapping peaks with sub-ridges."""
    xs = sorted(r.uniform(-100, W + 100) for _ in range(n))
    out = []
    for x in xs:
        h = r.uniform(hmin, hmax); w = r.uniform(260, 520)
        left = []; right = []
        steps = 7
        for k in range(steps + 1):
            t = k / steps
            jitter = r.uniform(-0.06, 0.06) * h * (1 - t)
            left.append((x - w/2 * t + r.uniform(-12, 12) * (k % 2), base - h * (1 - t) ** 1.15 + jitter))
            right.append((x + w/2 * t + r.uniform(-12, 12) * (k % 2), base - h * (1 - t) ** 1.25 + jitter))
        pts = list(reversed(left)) + right[1:]
        d = 'M' + ' L'.join(f'{px:.0f},{py:.0f}' for px, py in pts) + f' L{x + w/2:.0f},{H} L{x - w/2:.0f},{H} Z'
        out.append(f'<path d="{d}" fill="{color}" opacity="{op}"/>')
        # light side
        out.append(f'<path d="M{x:.0f},{base - h:.0f} L{right[3][0]:.0f},{right[3][1]:.0f} L{x + w*0.05:.0f},{base - h*0.35:.0f} Z" fill="#ffffff" opacity=".035"/>')
        if snow:
            sx = [p for p in pts if p[1] < base - h * 0.72]
            if len(sx) >= 3:
                d2 = 'M' + ' L'.join(f'{px:.0f},{py:.0f}' for px, py in sx) + ' Z'
                out.append(f'<path d="{d2}" fill="#d8efe6" opacity=".22"/>')
    return ''.join(out)

def code_rain(r, count=60, color=EL, op=.35, ymin=0, ymax=H):
    glyphs = '01{}<>=;/()[]$#ابپتجحخدرسشصطعفقکلمنوهی'
    out = []
    for _ in range(count):
        x = r.uniform(0, W); y0 = r.uniform(ymin, ymax)
        n = r.randint(6, 18)
        for k in range(n):
            ch = r.choice(glyphs)
            o = op * (k + 1) / n
            out.append(f'<text x="{x:.0f}" y="{y0 + k*26:.0f}" font-family="monospace" font-size="20" fill="{color}" opacity="{o:.2f}">{ch}</text>')
    return ''.join(out)

def window(x, y, w, h, title='', color=E, lines=8, r=None, red=False):
    c = '#c0392b' if red else color
    out = [f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="10" fill="#020806" stroke="{c}" stroke-width="2" opacity=".92"/>',
           f'<rect x="{x}" y="{y}" width="{w}" height="34" rx="10" fill="{c}" opacity=".35"/>',
           f'<text x="{x+14}" y="{y+23}" font-family="monospace" font-size="16" fill="{GL if not red else "#ffb3a8"}">{title}</text>']
    r = r or random.Random(x * 7 + y)
    for i in range(lines):
        lw = r.uniform(.3, .9) * (w - 40)
        out.append(f'<rect x="{x+20+r.uniform(0,40):.0f}" y="{y+54+i*((h-70)/lines):.0f}" width="{lw:.0f}" height="7" rx="3" fill="{c if i%3 else G}" opacity="{r.uniform(.35,.8):.2f}"/>')
    return ''.join(out)

def network(r, nodes, color=EL, op=.6, link=170):
    out = []
    for i, (x1, y1) in enumerate(nodes):
        for (x2, y2) in nodes[i+1:]:
            if math.hypot(x1-x2, y1-y2) < link:
                out.append(f'<line x1="{x1:.0f}" y1="{y1:.0f}" x2="{x2:.0f}" y2="{y2:.0f}" stroke="{color}" stroke-width="1.4" opacity="{op*0.6:.2f}"/>')
    for (x, y) in nodes:
        out.append(f'<circle cx="{x:.0f}" cy="{y:.0f}" r="9" fill="url(#glowE)"/><circle cx="{x:.0f}" cy="{y:.0f}" r="2.6" fill="{GL}"/>')
    return ''.join(out)

def khd_mark(cx, cy, s, color=G):
    # simplified KHD wordmark with wifi arcs and a curve (drawn, not the official asset)
    out = [f'<g transform="translate({cx},{cy}) scale({s})">']
    for i, rr in enumerate([40, 70, 100]):
        out.append(f'<path d="M{-rr*0.8:.0f},{-60 - rr*0.25:.0f} A{rr},{rr} 0 0 1 {rr*0.8:.0f},{-60 - rr*0.25:.0f}" fill="none" stroke="{color}" stroke-width="10" stroke-linecap="round" opacity="{1 - i*0.2}"/>')
    out.append(f'<text x="0" y="60" text-anchor="middle" font-family="Cinzel" font-weight="700" font-size="120" fill="{color}" letter-spacing="6">KHD</text>')
    out.append(f'<path d="M-170,95 Q0,150 170,85" fill="none" stroke="{color}" stroke-width="8" stroke-linecap="round"/>')
    out.append('</g>')
    return ''.join(out)

def arch(x, y, w, h, color=G, sw=4, op=1):
    return (f'<path d="M{x},{y+h} L{x},{y+w*0.5} Q{x},{y} {x+w/2},{y-w*0.15} Q{x+w},{y} {x+w},{y+w*0.5} L{x+w},{y+h}" '
            f'fill="none" stroke="{color}" stroke-width="{sw}" opacity="{op}"/>')

# ---------------- scenes ----------------

def s1(r):  # mountains, remote village, horizon
    o = [f'<rect width="{W}" height="{H}" fill="url(#sky)"/>', stars(r, 160, 700)]
    o.append(f'<circle cx="760" cy="980" r="380" fill="url(#sun)" opacity=".75"/>')
    o.append(peaks(r, 1080, 9, 260, 520, '#0a1f18', .95, snow=True))
    o.append(peaks(r, 1220, 8, 180, 360, '#06140f', 1))
    for i in range(14):  # village lights
        x = 180 + r.uniform(0, 420); y = 1230 + r.uniform(-30, 40)
        o.append(f'<rect x="{x:.0f}" y="{y:.0f}" width="{r.uniform(26,48):.0f}" height="{r.uniform(18,30):.0f}" fill="#120d06"/><rect x="{x+8:.0f}" y="{y+6:.0f}" width="6" height="6" fill="{GL}" opacity="{r.uniform(.4,.95):.2f}"/>')
    o.append(ridge(r, 1400, 80, 40, K))
    o.append(f'<circle cx="980" cy="1330" r="40" fill="url(#glowE)"/>')
    return ''.join(o)

def s2(r):  # dark room, device glow, code
    o = [f'<rect width="{W}" height="{H}" fill="{K}"/>', code_rain(r, 70, EL, .28)]
    o.append(f'<ellipse cx="600" cy="1250" rx="520" ry="300" fill="url(#glowE)" opacity=".55" filter="url(#blur30)"/>')
    o.append(f'<rect x="330" y="1180" width="540" height="330" rx="14" fill="#03100b" stroke="{E}" stroke-width="3"/>')
    o.append(window(350, 1200, 500, 290, '~/khorasan $', E, 9, r))
    o.append(f'<path d="M250,1515 L950,1515 L1010,1570 L190,1570 Z" fill="#0b1712" stroke="{E}" stroke-width="2"/>')
    o.append(f'<rect x="0" y="1570" width="{W}" height="230" fill="#010302"/>')
    return ''.join(o)

def s3(r):  # multiple monitors, architecture
    o = [f'<rect width="{W}" height="{H}" fill="{K}"/>', stars(r, 60, H, EL)]
    pos = [(60, 900, 340, 230), (430, 860, 360, 260), (820, 900, 330, 230), (180, 1170, 340, 220), (700, 1170, 340, 220)]
    titles = ['users', 'khorasan-api', 'wallet', 'orders', 'telegram-bot']
    for (x, y, w, h), t in zip(pos, titles):
        o.append(window(x, y, w, h, t, E, 6, r))
    cs = [(230, 1015), (610, 990), (985, 1015), (350, 1280), (870, 1280)]
    for a, b in [(0,1),(1,2),(1,3),(1,4),(3,4)]:
        o.append(f'<line x1="{cs[a][0]}" y1="{cs[a][1]}" x2="{cs[b][0]}" y2="{cs[b][1]}" stroke="{G}" stroke-width="3" stroke-dasharray="10 8" opacity=".8"/>')
    o.append(f'<ellipse cx="600" cy="1100" rx="600" ry="300" fill="url(#glowE)" opacity=".25" filter="url(#blur30)"/>')
    return ''.join(o)

def s4(r):  # brand birth, gold emblem
    o = [f'<rect width="{W}" height="{H}" fill="{K}"/>']
    for i in range(48):
        a = i * math.pi * 2 / 48
        o.append(f'<line x1="600" y1="1050" x2="{600+1400*math.cos(a):.0f}" y2="{1050+1400*math.sin(a):.0f}" stroke="{G}" stroke-width="2" opacity="{.05 + .1*(i%3==0):.2f}"/>')
    o.append(f'<circle cx="600" cy="1050" r="420" fill="url(#sun)" opacity=".45"/>')
    for k in range(3):
        o.append(f'<circle cx="600" cy="1050" r="{300+k*70}" fill="none" stroke="{G}" stroke-width="1.5" opacity="{.5-k*.12}"/>')
    o.append(khd_mark(600, 1080, 1.55, GL))
    o.append(stars(r, 120, H, GL))
    return ''.join(o)

def s5(r):  # wallet, transactions, receipt
    o = [f'<rect width="{W}" height="{H}" fill="{K}"/>']
    for i in range(22):  # transaction rows
        y = 820 + i * 42
        o.append(f'<rect x="70" y="{y}" width="430" height="30" rx="6" fill="{ED}" opacity=".7"/><text x="85" y="{y+21}" font-family="monospace" font-size="16" fill="{EL}">TX-{r.randint(100000,999999)}</text><text x="485" y="{y+21}" text-anchor="end" font-family="monospace" font-size="16" fill="{G}">{"+" if r.random()>.4 else "-"}{r.randint(50,9000):,}</text>')
    o.append(f'<g transform="rotate(-6 860 1150)"><rect x="660" y="830" width="400" height="640" rx="14" fill="#f7f2e3" opacity=".95"/>'
             f'<rect x="660" y="830" width="400" height="90" rx="14" fill="{ED}"/>'
             f'<text x="860" y="888" text-anchor="middle" font-family="Cinzel" font-weight="700" font-size="34" fill="{GL}">RECEIPT</text>')
    for i in range(7):
        o.append(f'<rect x="700" y="{960+i*38}" width="{r.randint(150,320)}" height="12" rx="4" fill="#3a3a3a" opacity=".5"/>')
    for i in range(9):
        for j in range(9):
            if r.random() > .45 or (i < 3 and j < 3) or (i < 3 and j > 5) or (i > 5 and j < 3):
                o.append(f'<rect x="{785+j*16}" y="{1260+i*16}" width="15" height="15" fill="#06281d"/>')
    o.append('</g>')
    for i in range(16):
        x, y = r.uniform(80, 1120), r.uniform(560, 800)
        o.append(f'<circle cx="{x:.0f}" cy="{y:.0f}" r="{r.uniform(18,34):.0f}" fill="url(#goldv)" opacity=".75"/>')
    return ''.join(o)

def s6(r):  # map of connected villages
    o = [f'<rect width="{W}" height="{H}" fill="url(#sky)"/>', stars(r, 80, 600)]
    o.append(peaks(r, 1500, 10, 200, 520, '#07160f', .9))
    nodes = [(r.uniform(80, 1120), r.uniform(800, 1500)) for _ in range(34)]
    o.append(network(r, nodes, EL, .8, 260))
    for (x, y) in nodes[:10]:
        o.append(f'<line x1="{x:.0f}" y1="{y:.0f}" x2="{x:.0f}" y2="{y-60:.0f}" stroke="{G}" stroke-width="2"/>'
                 f'<path d="M{x-14:.0f},{y-70:.0f} A18,18 0 0 1 {x+14:.0f},{y-70:.0f}" fill="none" stroke="{GL}" stroke-width="2"/>')
    return ''.join(o)

def s7(r):  # Karban: attendance grid + scaffold
    o = [f'<rect width="{W}" height="{H}" fill="{K}"/>']
    for i in range(7):
        for j in range(5):
            x, y = 640 + i * 70, 830 + j * 70
            ok = r.random() > .18
            o.append(f'<rect x="{x}" y="{y}" width="60" height="60" rx="8" fill="{ED if ok else "#1a1a1a"}" stroke="{E}" stroke-width="1.5"/>')
            if ok:
                o.append(f'<path d="M{x+16},{y+31} L{x+27},{y+42} L{x+45},{y+20}" fill="none" stroke="{GL}" stroke-width="4" stroke-linecap="round"/>')
    for k in range(6):  # scaffold building
        y = 1650 - k * 140
        o.append(f'<line x1="80" y1="{y}" x2="560" y2="{y}" stroke="{G}" stroke-width="5" opacity=".7"/>')
    for x in range(80, 600, 120):
        o.append(f'<line x1="{x}" y1="950" x2="{x}" y2="1650" stroke="{G}" stroke-width="5" opacity=".7"/>')
    for k in range(5):
        y = 1650 - k * 140
        o.append(f'<line x1="80" y1="{y}" x2="200" y2="{y-140}" stroke="{G}" stroke-width="2" opacity=".4"/>')
    o.append(f'<circle cx="320" cy="880" r="240" fill="url(#sun)" opacity=".3"/>')
    return ''.join(o)

def s8(r):  # data center / servers in clouds
    o = [f'<rect width="{W}" height="{H}" fill="{K}"/>']
    for i in range(8):  # perspective racks
        for side in (-1, 1):
            x = 600 + side * (120 + i * 70)
            hh = 900 - i * 60
            w = 60 + i * 6
            xx = x if side > 0 else x - w
            o.append(f'<rect x="{xx:.0f}" y="{1650-hh:.0f}" width="{w:.0f}" height="{hh:.0f}" fill="#04110c" stroke="{E}" stroke-width="1.5"/>')
            for k in range(int(hh / 30)):
                if r.random() > .4:
                    o.append(f'<rect x="{xx+8:.0f}" y="{1660-hh+k*30:.0f}" width="5" height="5" fill="{EL if r.random()>.2 else G}"/>')
    o.append(f'<path d="M560,1650 L640,1650 L1200,1800 L0,1800 Z" fill="{ED}" opacity=".6"/>')
    for i in range(7):
        cx, cy = r.uniform(100, 1100), r.uniform(560, 760)
        o.append(f'<ellipse cx="{cx:.0f}" cy="{cy:.0f}" rx="{r.uniform(160,280):.0f}" ry="{r.uniform(40,70):.0f}" fill="#cfe9df" opacity=".07" filter="url(#blur8)"/>')
    o.append(f'<rect x="585" y="760" width="30" height="900" fill="url(#glowE)" opacity=".5"/>')
    return ''.join(o)

def s9(r):  # shutdown, red errors
    o = [f'<rect width="{W}" height="{H}" fill="#050101"/>']
    o.append(f'<ellipse cx="600" cy="1150" rx="650" ry="500" fill="url(#glowR)" opacity=".35" filter="url(#blur30)"/>')
    for i in range(9):
        x, y = r.uniform(-60, 800), r.uniform(780, 1500)
        o.append(window(int(x), int(y), int(r.uniform(300, 420)), int(r.uniform(160, 240)), r.choice(['ERROR 500', 'FATAL', 'TIMEOUT', 'connection refused', '502 Bad Gateway']), E, 4, r, red=True))
    for i in range(30):  # glitch bars
        y = r.uniform(760, 1700)
        o.append(f'<rect x="{r.uniform(0,600):.0f}" y="{y:.0f}" width="{r.uniform(100,700):.0f}" height="{r.uniform(2,8):.0f}" fill="{r.choice(["#ff3b30", EL, "#ffffff"])}" opacity="{r.uniform(.1,.45):.2f}"/>')
    o.append(f'<circle cx="600" cy="1150" r="70" fill="none" stroke="#ff3b30" stroke-width="8" opacity=".85"/><line x1="600" y1="1090" x2="600" y2="1150" stroke="#ff3b30" stroke-width="8" stroke-linecap="round"/>')
    return ''.join(o)

def s10(r):  # corridor of doors / failed APIs
    o = [f'<rect width="{W}" height="{H}" fill="{K}"/>']
    vx, vy = 600, 1100
    for side in (-1, 1):
        for i in range(9):
            t1, t2 = i / 9, (i + .7) / 9
            def P(t, yy):
                return vx + side * (580 * (1 - t) + 30 * t), vy + (yy - vy) * (1 - t)
            x1, yt1 = P(t1, 700); _, yb1 = P(t1, 1750)
            x2, yt2 = P(t2, 700); _, yb2 = P(t2, 1750)
            o.append(f'<path d="M{x1:.0f},{yt1:.0f} L{x2:.0f},{yt2:.0f} L{x2:.0f},{yb2:.0f} L{x1:.0f},{yb1:.0f} Z" fill="#071510" stroke="{G}" stroke-width="2" opacity="{.95 - i*.07:.2f}"/>')
            if i % 2 == 0:
                o.append(f'<text x="{(x1+x2)/2:.0f}" y="{(yt1+yb1)/2:.0f}" text-anchor="middle" font-family="monospace" font-size="{max(10, 30 - i*3)}" fill="#ff6b5e" opacity=".8">403</text>')
    o.append(f'<rect x="575" y="1055" width="50" height="90" fill="{EL}" opacity=".9"/><rect x="560" y="1040" width="80" height="120" fill="url(#glowE)"/>')
    o.append(f'<path d="M560,1145 L640,1145 L900,1800 L300,1800 Z" fill="{EL}" opacity=".08"/>')
    return ''.join(o)

def s11(r):  # accounting dashboard
    o = [f'<rect width="{W}" height="{H}" fill="{K}"/>']
    o.append(f'<rect x="60" y="800" width="1080" height="820" rx="24" fill="#03110b" stroke="{E}" stroke-width="2"/>')
    for i, lab in enumerate(['درآمد', 'هزینه', 'بدهی', 'سود']):
        x = 100 + i * 255
        o.append(f'<rect x="{x}" y="840" width="230" height="130" rx="14" fill="{ED}"/><text x="{x+210}" y="885" text-anchor="end" font-family="Vazirmatn" font-size="24" fill="{EL}">{lab}</text>'
                 f'<text x="{x+210}" y="945" text-anchor="end" font-family="Cinzel" font-weight="700" font-size="40" fill="{GL}">{r.randint(10,99)},{r.randint(100,999)}</text>')
    for i in range(12):
        h = r.uniform(80, 360)
        o.append(f'<rect x="{120+i*48}" y="{1400-h:.0f}" width="30" height="{h:.0f}" rx="4" fill="{"url(#goldv)" if i%2 else E}"/>')
    pts = ' '.join(f'{740+i*36:.0f},{1350 - 200*abs(math.sin(i/2.5)) - i*8:.0f}' for i in range(11))
    o.append(f'<polyline points="{pts}" fill="none" stroke="{GL}" stroke-width="5"/>')
    o.append(f'<line x1="100" y1="1460" x2="1100" y2="1460" stroke="{E}" stroke-width="1.5"/>')
    for i in range(3):
        o.append(f'<rect x="100" y="{1490+i*36}" width="1000" height="22" rx="5" fill="{ED}" opacity=".8"/>')
    return ''.join(o)

def s12(r):  # many versions, code windows
    o = [f'<rect width="{W}" height="{H}" fill="{K}"/>', code_rain(r, 30, G, .18)]
    vers = ['v50', 'v51', 'v53', 'v54', 'v55', 'v43', 'v44', 'v46']
    for i, v in enumerate(vers):
        x = 90 + (i % 4) * 40 + (i // 4) * 480
        y = 780 + (i % 4) * 150
        o.append(window(int(x), int(y), 520, 300, f'khorasan-{v}', E if i % 3 else '#8a6a22', 7, r))
    o.append(f'<circle cx="600" cy="1500" r="200" fill="url(#sun)" opacity=".55"/>')
    o.append(f'<text x="600" y="1530" text-anchor="middle" font-family="Cinzel" font-weight="700" font-size="90" fill="{GL}">FINAL</text>')
    return ''.join(o)

def s13(r):  # alone in office, storm window
    o = [f'<rect width="{W}" height="{H}" fill="#020403"/>']
    o.append(f'<rect x="300" y="700" width="600" height="760" fill="#06140f" stroke="{G}" stroke-width="6"/>')
    o.append(f'<line x1="600" y1="700" x2="600" y2="1460" stroke="{G}" stroke-width="4"/><line x1="300" y1="1080" x2="900" y2="1080" stroke="{G}" stroke-width="4"/>')
    for i in range(140):
        x = r.uniform(305, 895); y = r.uniform(705, 1440)
        o.append(f'<line x1="{x:.0f}" y1="{y:.0f}" x2="{x-12:.0f}" y2="{y+40:.0f}" stroke="#9fc9bb" stroke-width="1.2" opacity=".35"/>')
    o.append(f'<path d="M520,720 L470,880 L540,880 L480,1050" fill="none" stroke="{GL}" stroke-width="4" opacity=".7"/>')
    o.append(f'<rect x="120" y="1530" width="960" height="40" fill="#1b130a"/><rect x="180" y="1570" width="26" height="230" fill="#1b130a"/><rect x="994" y="1570" width="26" height="230" fill="#1b130a"/>')
    o.append(f'<path d="M820,1530 L850,1400 L900,1400 L930,1530" fill="#2a1f0e"/><ellipse cx="875" cy="1520" rx="200" ry="70" fill="url(#sun)" opacity=".6"/>')
    return ''.join(o)

def s14(r):  # rebuild + sunrise
    o = [f'<rect width="{W}" height="{H}" fill="url(#sky)"/>']
    o.append(f'<circle cx="600" cy="1250" r="560" fill="url(#sun)" opacity=".85"/>')
    o.append(ridge(r, 1350, 60, 30, '#06140f'))
    o.append(f'<rect x="250" y="1050" width="700" height="420" fill="#04110c" stroke="{G}" stroke-width="3"/>')
    for i in range(5):
        o.append(arch(285 + i * 132, 1150, 100, 320, G, 4))
    o.append(f'<path d="M420,1050 Q600,820 780,1050 Z" fill="#04110c" stroke="{G}" stroke-width="4"/>')
    for i in range(10):  # scaffolding / rebuild lines
        o.append(f'<line x1="{220+i*80}" y1="1470" x2="{220+i*80}" y2="{1000 - (i%3)*30}" stroke="{EL}" stroke-width="1.5" opacity=".35"/>')
    o.append(f'<rect x="0" y="1470" width="{W}" height="330" fill="#020604"/>')
    return ''.join(o)

def s15(r):  # future network over the land
    o = [f'<rect width="{W}" height="{H}" fill="{K}"/>']
    o.append(f'<ellipse cx="600" cy="1900" rx="1100" ry="900" fill="#04140e" stroke="{E}" stroke-width="2"/>')
    for k in range(1, 7):
        o.append(f'<ellipse cx="600" cy="1900" rx="{1100 - k*150}" ry="{900 - k*120}" fill="none" stroke="{E}" stroke-width="1" opacity=".4"/>')
    for k in range(-6, 7):
        o.append(f'<path d="M600,1000 Q{600 + k*160},1400 {600 + k*190},1800" fill="none" stroke="{E}" stroke-width="1" opacity=".35"/>')
    nodes = [(r.uniform(60, 1140), r.uniform(1050, 1750)) for _ in range(40)]
    o.append(network(r, nodes, EL, .9, 230))
    for i in range(12):
        x1, y1 = r.choice(nodes); x2, y2 = r.uniform(100, 1100), r.uniform(700, 900)
        o.append(f'<path d="M{x1:.0f},{y1:.0f} Q{(x1+x2)/2:.0f},{min(y1,y2)-200:.0f} {x2:.0f},{y2:.0f}" fill="none" stroke="{G}" stroke-width="1.6" stroke-dasharray="6 8" opacity=".6"/>')
    o.append(stars(r, 100, 900, GL))
    return ''.join(o)

def s16(r):  # summit, horizon, heritage + tech
    o = [f'<rect width="{W}" height="{H}" fill="url(#sky)"/>', stars(r, 90, 700, GL)]
    o.append(f'<circle cx="600" cy="1120" r="620" fill="url(#sun)" opacity=".9"/>')
    for i in range(7):
        o.append(arch(40 + i * 165, 900, 130, 380, G, 2.5, .25))
    nodes = [(r.uniform(40, 1160), r.uniform(1150, 1450)) for _ in range(24)]
    o.append(network(r, nodes, EL, .6, 220))
    o.append(peaks(r, 1420, 9, 150, 380, '#06140f', .95, snow=True))
    o.append(f'<path d="M180,1800 L600,1380 L1020,1800 Z" fill="#020604"/>')
    o.append(f'<path d="M560,1420 L600,1380 L640,1420" fill="none" stroke="{GL}" stroke-width="3" opacity=".7"/>')
    return ''.join(o)

SCENES = [s1, s2, s3, s4, s5, s6, s7, s8, s9, s10, s11, s12, s13, s14, s15, s16]

def scene_svg(n):
    r = rng(n)
    return f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W} {H}" width="{W}" height="{H}" preserveAspectRatio="xMidYMid slice">{DEFS}{SCENES[n-1](r)}</svg>'
