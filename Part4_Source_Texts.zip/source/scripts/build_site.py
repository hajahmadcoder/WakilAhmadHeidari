"""Builds a single, self-contained static website for the book (deployable on any host / cPanel)."""
import os, shutil, html, glob
from PIL import Image
from common import BASE, all_episodes, fa, SEASONS, body_to_html

SRC = os.path.join(BASE, 'out', 'THE_LAST_CODE_OF_KHORASAN')
SITE = os.path.join(BASE, 'site', 'khorasan-book')
shutil.rmtree(SITE, ignore_errors=True)
for d in ['assets/css', 'assets/fonts', 'assets/img/posters', 'assets/img/thumbs', 'episodes',
          'downloads/pdf']:
    os.makedirs(os.path.join(SITE, d), exist_ok=True)
J = lambda *p: os.path.join(SITE, *p)

# fonts (web)
for w in ['Regular', 'Medium', 'Bold', 'Black']:
    shutil.copy(os.path.join(BASE, 'package/fonts/webfonts', f'Vazirmatn-{w}.woff2'), J('assets/fonts'))
shutil.copy(os.path.join(BASE, 'fonts/cinzel-latin-700-normal.woff2'), J('assets/fonts/Cinzel-Bold.woff2'))
shutil.copy(os.path.join(BASE, 'package/OFL.txt') if os.path.exists(os.path.join(BASE, 'package/OFL.txt')) else os.path.join(BASE, 'package/LICENSE'), J('assets/fonts/OFL-Vazirmatn.txt'))

# images
def web_img(src, dst, size, q):
    im = Image.open(src).convert('RGB'); im = im.resize(size, Image.LANCZOS); im.save(dst, 'JPEG', quality=q, optimize=True, progressive=True)
web_img(os.path.join(SRC, 'Main_Cover.png'), J('assets/img/cover.jpg'), (1200, 1800), 84)
web_img(os.path.join(SRC, 'Main_Cover.png'), J('assets/img/og-cover.jpg'), (800, 1200), 80)
for n in range(1, 17):
    p = os.path.join(SRC, 'Posters', f'Poster_{n:02d}.png')
    web_img(p, J('assets/img/posters', f'poster-{n:02d}.jpg'), (1200, 1800), 84)
    web_img(p, J('assets/img/thumbs', f'poster-{n:02d}.jpg'), (480, 720), 78)
# pdfs
shutil.copy(os.path.join(SRC, 'Complete_Book.pdf'), J('downloads/pdf'))
for p in glob.glob(os.path.join(SRC, 'Season_*', '*.pdf')):
    shutil.copy(p, J('downloads/pdf'))
# banner
web_img(os.path.join(SRC, 'Banner.png'), J('assets/img/banner.jpg'), (1920, 1080), 84)

CSS = '''@font-face{font-family:Vazirmatn;font-weight:400;font-display:swap;src:url(../fonts/Vazirmatn-Regular.woff2) format("woff2")}
@font-face{font-family:Vazirmatn;font-weight:500;font-display:swap;src:url(../fonts/Vazirmatn-Medium.woff2) format("woff2")}
@font-face{font-family:Vazirmatn;font-weight:700;font-display:swap;src:url(../fonts/Vazirmatn-Bold.woff2) format("woff2")}
@font-face{font-family:Vazirmatn;font-weight:900;font-display:swap;src:url(../fonts/Vazirmatn-Black.woff2) format("woff2")}
@font-face{font-family:Cinzel;font-weight:700;font-display:swap;src:url(../fonts/Cinzel-Bold.woff2) format("woff2")}
:root{--bg:#030806;--panel:#07150f;--line:rgba(217,180,90,.28);--gold:#d9b45a;--gold2:#f4dd9a;--em:#38d39f;--emd:#0b5a40;--tx:#e9e3cf;--mut:#9fb3aa}
*{box-sizing:border-box}html{scroll-behavior:smooth}
body{margin:0;background:var(--bg);color:var(--tx);font-family:Vazirmatn,Tahoma,sans-serif;line-height:1.9;direction:rtl}
a{color:var(--gold2);text-decoration:none}a:hover{color:var(--em)}
img{max-width:100%;height:auto;display:block}
.wrap{max-width:1180px;margin:0 auto;padding:0 20px}
.nav{position:sticky;top:0;z-index:10;background:rgba(3,8,6,.88);backdrop-filter:blur(8px);border-bottom:1px solid var(--line)}
.nav .wrap{display:flex;align-items:center;justify-content:space-between;height:60px;gap:14px}
.brand{font-weight:900;color:var(--gold2);white-space:nowrap}.brand small{font-family:Cinzel;color:var(--gold);letter-spacing:3px;font-size:11px;margin-right:10px}
.nav .links{display:flex;gap:18px;font-size:14px;flex-wrap:wrap}
.hero{display:grid;grid-template-columns:minmax(0,420px) 1fr;gap:48px;align-items:center;padding:56px 0}
.hero img{border:1px solid var(--line);box-shadow:0 30px 80px rgba(0,0,0,.7)}
.en{font-family:Cinzel;letter-spacing:6px;color:var(--gold);font-size:15px}
h1.big{font-weight:900;font-size:clamp(40px,6vw,72px);line-height:1.2;margin:10px 0;background:linear-gradient(180deg,#fff3c9,#e6c574 55%,#9a7428);-webkit-background-clip:text;background-clip:text;color:transparent}
.lead{font-size:18px;color:var(--tx);max-width:620px}
.meta{color:var(--em);font-weight:500;margin:14px 0 26px}
.btn{display:inline-block;padding:12px 22px;border:1px solid var(--gold);color:var(--gold2);border-radius:6px;font-weight:700;margin:4px 0 4px 10px;transition:.2s}
.btn.primary{background:linear-gradient(180deg,#e6c574,#a9822f);color:#1b1306;border-color:transparent}
.btn:hover{transform:translateY(-1px);color:var(--em)}.btn.primary:hover{color:#000}
section{padding:40px 0;border-top:1px solid var(--line)}
h2.sec{font-size:28px;font-weight:900;color:var(--gold2);margin:0 0 6px}
.sub{color:var(--mut);margin:0 0 26px}
.season h3{font-size:20px;color:var(--em);margin:30px 0 4px}.season p.si{color:var(--mut);margin:0 0 18px;max-width:820px}
.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:20px}
.card{background:var(--panel);border:1px solid var(--line);border-radius:8px;overflow:hidden;transition:.25s;display:flex;flex-direction:column}
.card:hover{transform:translateY(-4px);border-color:var(--gold)}
.card .b{padding:12px 14px 16px}.card .n{font-size:12px;color:var(--em)}.card .t{font-weight:700;color:var(--gold2);font-size:16px;line-height:1.6}
.card .g{font-size:13px;color:var(--mut);margin-top:6px}
.prose{max-width:760px}.prose p{margin:0 0 14px}
.dl{display:grid;grid-template-columns:repeat(auto-fill,minmax(250px,1fr));gap:10px}
.dl a{display:flex;justify-content:space-between;background:var(--panel);border:1px solid var(--line);border-radius:6px;padding:10px 14px;font-size:14px}
.dl a span{color:var(--mut);font-size:12px;direction:ltr}
footer{border-top:1px solid var(--line);padding:30px 0;color:var(--mut);font-size:13px;text-align:center}
/* reader */
.ep-hero{display:grid;grid-template-columns:minmax(0,340px) 1fr;gap:40px;padding:40px 0;align-items:end}
.ep-hero img{border:1px solid var(--line)}
.kicker{color:var(--em);font-weight:500}
.ep-hero h1{font-size:clamp(32px,5vw,54px);font-weight:900;color:var(--gold2);margin:6px 0;line-height:1.3}
.cine{color:var(--mut);font-size:18px}
.tagline{border-right:4px solid var(--gold);background:rgba(217,180,90,.08);padding:14px 18px;margin:20px 0;font-weight:700;font-size:19px;color:var(--gold2)}
.intro{background:rgba(56,211,159,.07);border-radius:8px;padding:14px 18px;color:var(--tx)}
article{max-width:760px;margin:0 auto;padding:10px 0 40px;font-size:18px;line-height:2.15;text-align:justify}
article h2{font-size:24px;color:var(--gold2);border-bottom:1px solid var(--line);padding-bottom:8px;margin:46px 0 18px}
article h3{font-size:19px;color:var(--em);margin:32px 0 10px}
article h3 .sl{font-size:12px;background:var(--emd);color:#fff;border-radius:4px;padding:2px 8px;margin-left:10px;vertical-align:middle}
article p{margin:0 0 16px}
article p.dlg{padding-right:16px;border-right:2px solid rgba(56,211,159,.35)}
article p.dlg b{color:var(--em);margin-left:8px}article p.dlg b:after{content:":"}
article blockquote.narr{margin:22px 0;padding:16px 20px;background:#0c1d16;border:1px solid var(--line);border-radius:8px;color:var(--gold2)}
article blockquote.narr .who{display:block;font-size:12px;color:var(--gold);letter-spacing:1px;margin-bottom:4px}
article p.note{font-size:14px;color:var(--mut);background:rgba(255,255,255,.04);padding:8px 12px;border-radius:6px}
.pager{display:flex;justify-content:space-between;gap:12px;max-width:760px;margin:0 auto 50px;flex-wrap:wrap}
.end{text-align:center;color:var(--gold);margin:30px 0}
.banner{margin:24px 0 0;border:1px solid var(--line);border-radius:10px;overflow:hidden}
.progress{max-width:760px;margin:0 auto 6px;color:var(--mut);font-size:14px;display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap}
.bar{height:6px;background:#10241b;border-radius:4px;overflow:hidden;max-width:760px;margin:0 auto 10px}.bar i{display:block;height:100%;background:linear-gradient(90deg,var(--em),var(--gold))}
select.jump{background:var(--panel);color:var(--gold2);border:1px solid var(--line);border-radius:6px;padding:6px 10px;font-family:inherit;font-size:14px}
.steps{display:flex;gap:6px;flex-wrap:wrap;justify-content:center;max-width:760px;margin:0 auto 40px}
.steps a{min-width:36px;text-align:center;padding:4px 0;border:1px solid var(--line);border-radius:5px;font-size:13px;color:var(--mut)}
.steps a.on{background:var(--gold);color:#1b1306;border-color:var(--gold)}.steps a.done{color:var(--em);border-color:rgba(56,211,159,.4)}
table.pdfs{width:100%;border-collapse:collapse;font-size:15px}table.pdfs td{padding:10px 8px;border-bottom:1px solid var(--line)}
table.pdfs td.s{color:var(--mut);direction:ltr;text-align:left;font-size:13px;white-space:nowrap}table.pdfs .btn{padding:6px 12px;margin:2px;font-size:13px}
@media(max-width:760px){.hero,.ep-hero{grid-template-columns:1fr;gap:24px}.hero img,.ep-hero img{max-width:320px;margin:0 auto}.nav .links{display:none}.brand small{display:none}article{font-size:17px}}
'''
open(J('assets/css/style.css'), 'w', encoding='utf-8').write(CSS)

def page(title, body, root, desc='', og=''):
    return f'''<!doctype html>
<html lang="fa" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>{html.escape(title)}</title><meta name="description" content="{html.escape(desc)}">
<meta property="og:title" content="{html.escape(title)}"><meta property="og:description" content="{html.escape(desc)}"><meta property="og:image" content="{og or root + 'assets/img/banner.jpg'}">
<meta name="theme-color" content="#030806"><link rel="icon" href="{root}assets/img/thumbs/poster-01.jpg">
<link rel="preload" href="{root}assets/fonts/Vazirmatn-Regular.woff2" as="font" type="font/woff2" crossorigin>
<link rel="stylesheet" href="{root}assets/css/style.css"></head><body>
<header class="nav"><div class="wrap"><a class="brand" href="{root}index.html">آخرین کُد خراسان<small>THE LAST CODE OF KHORASAN</small></a>
<nav class="links"><a href="{root}index.html#episodes">قسمت‌ها</a><a href="{root}index.html#about">درباره‌ی کتاب</a><a href="{root}downloads.html">دانلود PDF</a><a href="https://khorasandigital.ir">خراسان دیجیتال</a></nav></div></header>
{body}
<footer><div class="wrap">آخرین کُد خراسان · نویسنده: وکیل احمد حیدری · © ۲۰۲۶ همه‌ی حقوق محفوظ است<br>
صحنه‌ها و شخصیت‌های فرعی بازسازی داستانی‌اند. · <a href="https://khorasandigital.ir">khorasandigital.ir</a> · <a href="https://t.me/Khorasandigital_app">‎@Khorasandigital_app</a></div></footer>
</body></html>'''

eps = all_episodes()
fs = {}
raw = open(os.path.join(BASE, 'frontmatter.txt'), encoding='utf-8').read()
for part in raw.split('## ')[1:]:
    t, b = part.split('\n', 1); fs[t.strip()] = b.strip()
paras = lambda t: ''.join(f'<p>{html.escape(l)}</p>' for l in t.split('\n') if l.strip())
size = lambda p: f'{os.path.getsize(p)/1048576:.1f} MB'

# episode pages
for ep in eps:
    n = ep['n']; s = ep['season']
    prev = f'<a class="btn" href="ep-{n-1:02d}.html">→ قسمت قبل</a>' if n > 1 else '<span></span>'
    nxt = f'<a class="btn primary" href="ep-{n+1:02d}.html">قسمت بعد ←</a>' if n < 16 else '<a class="btn primary" href="../index.html#about">پایان مجموعه</a>'
    jump = '<select class="jump" onchange="location.href=this.value">' + ''.join(f'<option value="ep-{e["n"]:02d}.html"{" selected" if e["n"]==n else ""}>قسمت {fa(e["n"])}: {html.escape(e["title"])}</option>' for e in eps) + '</select>'
    steps = ''.join(f'<a class="{"on" if e["n"]==n else ("done" if e["n"]<n else "")}" href="ep-{e["n"]:02d}.html">{fa(e["n"])}</a>' for e in eps)
    prog = f'<div class="progress" style="margin-top:22px"><span>مرحله‌ی {fa(n)} از ۱۶ · {SEASONS[s][1]}</span>{jump}</div><div class="bar"><i style="width:{n/16*100:.1f}%"></i></div>'
    body = f'''<main class="wrap">{prog}<div class="ep-hero"><img src="../assets/img/posters/poster-{n:02d}.jpg" alt="پوستر قسمت {fa(n)}: {html.escape(ep['title'])}" width="1200" height="1800">
<div><div class="kicker">{SEASONS[s][1]}: {html.escape(SEASONS[s][0])} · قسمت {fa(n)}</div><h1>{html.escape(ep['title'])}</h1><div class="cine">{html.escape(ep['cine_title'])}</div>
<div class="tagline">«{html.escape(ep['tagline'])}»</div><div class="intro">{html.escape(ep['intro'])}</div>
<p><a class="btn" href="../downloads/pdf/Episode_{n:02d}.pdf" target="_blank" rel="noopener">PDF این قسمت</a><a class="btn" href="../assets/img/posters/poster-{n:02d}.jpg" download="Poster_{n:02d}.jpg">دانلود پوستر</a></p></div></div>
<article>{body_to_html(ep['body'])}<div class="end">— پایان قسمت {fa(n)} —</div></article>
<div class="pager">{prev}<a class="btn" href="../index.html#episodes">همه‌ی قسمت‌ها</a>{nxt}</div><div class="steps">{steps}</div></main>'''
    open(J('episodes', f'ep-{n:02d}.html'), 'w', encoding='utf-8').write(
        page(f'قسمت {fa(n)}: {ep["title"]} | آخرین کُد خراسان', body, '../', ep['tagline'], f'../assets/img/posters/poster-{n:02d}.jpg'))

# index
seasons_html = ''
for s in (1, 2, 3):
    cards = ''.join(f'''<a class="card" href="episodes/ep-{e['n']:02d}.html"><img loading="lazy" src="assets/img/thumbs/poster-{e['n']:02d}.jpg" alt="{html.escape(e['title'])}" width="480" height="720">
<div class="b"><div class="n">قسمت {fa(e['n'])}</div><div class="t">{html.escape(e['title'])}</div><div class="g">{html.escape(e['tagline'])}</div></div></a>''' for e in eps if e['season'] == s)
    seasons_html += f'<div class="season"><h3>{SEASONS[s][1]}: {html.escape(SEASONS[s][0])}</h3><p class="si">{html.escape(SEASONS[s][2])}</p><div class="grid">{cards}</div></div>'
book = J('downloads/pdf/Complete_Book.pdf')
dls = f'<a href="downloads/pdf/Complete_Book.pdf" download>کتاب کامل <span>PDF · {size(book)}</span></a>'
dls += ''.join(f'<a href="downloads/pdf/Episode_{n:02d}.pdf" download>قسمت {fa(n)}: {html.escape(eps[n-1]["title"])} <span>PDF · {size(J("downloads/pdf", f"Episode_{n:02d}.pdf"))}</span></a>' for n in range(1, 17))
dls += '<a href="downloads/posters/Main_Cover.png" download>جلد اصلی <span>PNG</span></a>'
dls += ''.join(f'<a href="downloads/posters/Poster_{n:02d}.png" download>پوستر قسمت {fa(n)} <span>PNG</span></a>' for n in range(1, 17))
body = f'''<main class="wrap">
<div class="banner"><img src="assets/img/banner.jpg" alt="آخرین کُد خراسان — شانزده قسمت" width="1920" height="1080"></div>
<div class="hero"><img src="assets/img/cover.jpg" alt="جلد کتاب آخرین کُد خراسان" width="1200" height="1800">
<div><div class="en">THE LAST CODE OF KHORASAN</div><h1 class="big">آخرین کُد خراسان</h1>
<div class="meta">کتاب سینمایی در سه فصل و شانزده قسمت · نویسنده: وکیل احمد حیدری</div>
<p class="lead">داستان مردی که با یک گوشی، برنامه‌نویسی آموخت و «خراسان دیجیتال» را ساخت؛ از شب اول و یک سؤال ساده، تا سیستمی که خاموش شد، درهایی که باز نشدند، و آینده‌ای که هنوز نوشته نشده است.</p>
<p><a class="btn primary" href="episodes/ep-01.html">شروع خواندن</a><a class="btn" href="downloads.html">PDF کتاب و قسمت‌ها</a></p></div></div>
<section id="episodes"><h2 class="sec">قسمت‌ها</h2><p class="sub">سه فصل، شانزده قسمت؛ هر قسمت با پوستر اختصاصی.</p>{seasons_html}</section>
<section id="about"><h2 class="sec">درباره‌ی کتاب</h2><div class="prose">{paras(fs['پیشگفتار'])}</div>
<h2 class="sec" style="margin-top:30px">پایان‌بندی مجموعه</h2><div class="prose">{paras(fs['پایان‌بندی بزرگ مجموعه'])}</div>
<h2 class="sec" style="margin-top:30px">یادداشت نویسنده</h2><div class="prose">{paras(fs['یادداشت نویسنده'])}</div></section>
<section id="downloads"><h2 class="sec">دانلود</h2><p class="sub">PDF کتاب کامل و PDF جداگانه‌ی هر قسمت، جلد، بنر و پوسترها.</p><p><a class="btn primary" href="downloads.html">رفتن به صفحه‌ی دانلود</a></p></section>
</main>'''
open(J('index.html'), 'w', encoding='utf-8').write(page('آخرین کُد خراسان | THE LAST CODE OF KHORASAN', body, '', 'کتاب سینمایی در سه فصل و شانزده قسمت؛ نویسنده: وکیل احمد حیدری'))

rows = f'<tr><td><b>کتاب کامل</b> (۱۶ قسمت، با فهرست و پوسترها)</td><td class="s">{size(book)}</td><td><a class="btn" href="downloads/pdf/Complete_Book.pdf" target="_blank" rel="noopener">مشاهده</a><a class="btn primary" href="downloads/pdf/Complete_Book.pdf" download>دانلود</a></td></tr>'
for s_ in (1, 2, 3):
    rows += f'<tr><td colspan="3" style="color:var(--em);font-weight:700;padding-top:22px">{SEASONS[s_][1]}: {html.escape(SEASONS[s_][0])}</td></tr>'
    for e in eps:
        if e['season'] != s_: continue
        f_ = f'downloads/pdf/Episode_{e["n"]:02d}.pdf'
        rows += f'<tr><td>قسمت {fa(e["n"])}: {html.escape(e["title"])}</td><td class="s">{size(J(f_))}</td><td><a class="btn" href="{f_}" target="_blank" rel="noopener">مشاهده</a><a class="btn" href="{f_}" download>دانلود</a></td></tr>'
imgs = '<a href="assets/img/banner.jpg" download="Banner.jpg">بنر <span>JPG</span></a><a href="assets/img/cover.jpg" download="Main_Cover.jpg">جلد اصلی <span>JPG</span></a>' + ''.join(f'<a href="assets/img/posters/poster-{n:02d}.jpg" download="Poster_{n:02d}.jpg">پوستر قسمت {fa(n)} <span>JPG</span></a>' for n in range(1, 17))
dbody = f'''<main class="wrap"><section style="border:0"><h2 class="sec">دانلود PDF</h2><p class="sub">هر فایل جداگانه است؛ می‌توانید در مرورگر ببینید یا دانلود کنید.</p>
<table class="pdfs">{rows}</table></section><section><h2 class="sec">جلد، بنر و پوسترها</h2><p class="sub">۱۲۰۰×۱۸۰۰ پیکسل.</p><div class="dl">{imgs}</div></section></main>'''
open(J('downloads.html'), 'w', encoding='utf-8').write(page('دانلود PDF | آخرین کُد خراسان', dbody, '', 'PDF کتاب کامل و هر قسمت'))
open(J('404.html'), 'w', encoding='utf-8').write(page('صفحه پیدا نشد | آخرین کُد خراسان', '<main class="wrap" style="padding:80px 0;text-align:center"><h2 class="sec">این صفحه پیدا نشد</h2><p><a class="btn primary" href="/index.html">بازگشت به صفحه‌ی اصلی</a></p></main>', '/'))
open(J('_headers'), 'w').write('''/assets/*
  Cache-Control: public, max-age=2592000
/downloads/*
  Cache-Control: public, max-age=604800
/*.html
  Cache-Control: public, max-age=300
/*
  X-Content-Type-Options: nosniff
  Referrer-Policy: strict-origin-when-cross-origin
''')
open(J('_redirects'), 'w').write('/start /episodes/ep-01.html 302\n/book /downloads/pdf/Complete_Book.pdf 302\n')
# server files

open(J('robots.txt'), 'w').write('User-agent: *\nAllow: /\n')
print('site built')
