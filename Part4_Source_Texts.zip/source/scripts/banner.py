import os, subprocess
from common import BASE, font_css, all_episodes, fa
OUT = os.path.join(BASE, 'out', 'THE_LAST_CODE_OF_KHORASAN')
PHOTO = 'file://' + os.path.join(BASE, 'ref_photo.png')
TH = lambda n: 'file://' + os.path.join(BASE, 'tmp_pdf', 'img', f'p{n:02d}.jpg')
eps = all_episodes()
thumbs = ''.join(f'<div class="t"><img src="{TH(e["n"])}"><span>قسمت {fa(e["n"])}<b>{e["title"]}</b></span></div>' for e in eps)
html = f'''<!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8"><style>{font_css()}
*{{margin:0;padding:0;box-sizing:border-box}}
body{{width:1920px;height:1080px;overflow:hidden;background:#000;font-family:Vazirmatn;color:#efe6c8}}
.bg{{position:absolute;inset:0;background:radial-gradient(ellipse at 70% 40%,#0d4a35 0%,#03120c 45%,#000 80%)}}
.code{{position:absolute;inset:0;font-family:monospace;font-size:15px;line-height:22px;color:rgba(56,211,159,.05);white-space:pre;overflow:hidden;direction:ltr;padding:20px}}
.ph{{position:absolute;right:40px;top:-40px;width:760px;height:900px;background:url('{PHOTO}') 50% 18%/880px auto no-repeat;
  -webkit-mask-image:radial-gradient(ellipse 48% 52% at 50% 45%,#000 55%,transparent 100%);filter:contrast(1.08) saturate(.9)}}
.ph2{{position:absolute;left:640px;top:80px;width:420px;height:560px;background:url('{PHOTO}') 50% 20%/560px auto no-repeat;
  -webkit-mask-image:radial-gradient(ellipse 45% 48% at 50% 45%,#000 40%,transparent 100%);filter:grayscale(1) sepia(1) hue-rotate(110deg) saturate(2.4) brightness(.8);opacity:.45}}
.frame{{position:absolute;inset:22px;border:1.5px solid rgba(217,180,90,.5)}}
.txt{{position:absolute;left:80px;top:60px;width:860px;text-align:center}}
.k{{font-size:26px;color:#38d39f;font-weight:500}}
h1{{font-weight:900;font-size:118px;line-height:1.2;margin:6px 0 0;background:linear-gradient(180deg,#fff3c9,#e6c574 50%,#9a7428);-webkit-background-clip:text;background-clip:text;color:transparent;filter:drop-shadow(0 8px 26px #000)}}
.en{{font-family:Cinzel;font-weight:700;font-size:34px;letter-spacing:7px;white-space:nowrap;color:#e6c574}}
.rule{{width:420px;height:2px;margin:16px auto;background:linear-gradient(90deg,transparent,#d9b45a,transparent)}}
.tag{{font-size:27px;line-height:1.75}}
.by{{margin-top:12px;font-size:26px;color:#bfae7a}}.by b{{color:#e6c574}}
.row{{position:absolute;left:50px;right:50px;bottom:48px;display:grid;grid-template-columns:repeat(16,1fr);gap:10px}}
.t{{position:relative;border:1px solid rgba(217,180,90,.6);border-radius:6px;overflow:hidden;height:230px;background:#000}}
.t img{{width:100%;height:100%;object-fit:cover;object-position:50% 22%}}
.t span{{position:absolute;left:0;right:0;bottom:0;padding:26px 4px 6px;font-size:12px;line-height:1.5;text-align:center;color:#38d39f;background:linear-gradient(transparent,rgba(0,0,0,.92) 40%)}}
.t b{{display:block;color:#f2dc95;font-size:13px}}
.side{{position:absolute;right:70px;bottom:330px;font-size:24px;color:#e7dfc6;text-align:right;line-height:1.7;text-shadow:0 2px 10px #000}}
.side2{{position:absolute;left:1000px;top:60px;font-size:22px;color:#38d39f;letter-spacing:1px}}
</style></head><body><div class="bg"></div>
<div class="code">{("const khorasan = connect(villages, cities);  // 34 provinces\nwallet.debit(user, amount) // atomic\nif (!api.ok) build(newDoor);\n" * 60)}</div>
<div class="ph2"></div><div class="ph"></div><div class="frame"></div>
<div class="side2">سه فصل · شانزده قسمت · یک مسیر</div>
<div class="txt"><div class="k">یک داستان واقعی، دراماتیزه و سینمایی</div><h1>آخرین کُد خراسان</h1><div class="en">THE LAST CODE OF KHORASAN</div>
<div class="rule"></div><div class="tag">بعضی‌ها با نقشه به دنیا می‌آیند؛<br>بعضی‌ها باید نقشه را خودشان بکشند.</div>
<div class="by">نویسنده و شخصیت اصلی: <b>وکیل احمد حیدری</b></div></div>
<div class="side">شکست‌ها، تنهایی‌ها<br>و سیستمی که از یک گوشی ساخته شد</div>
<div class="row">{thumbs}</div></body></html>'''
hp = os.path.join(BASE, 'tmp_posters', 'banner.html'); open(hp, 'w', encoding='utf-8').write(html)
out = os.path.join(OUT, 'Banner.png')
subprocess.run(['google-chrome', '--headless=new', '--no-sandbox', '--hide-scrollbars', '--allow-file-access-from-files',
    '--force-device-scale-factor=1.5', '--window-size=1920,1080', '--virtual-time-budget=4000', f'--screenshot={out}', 'file://' + hp], check=True, capture_output=True)
print(out)
