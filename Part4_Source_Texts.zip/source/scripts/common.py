import os, re, glob, html

BASE = os.path.dirname(os.path.abspath(__file__))
FONTS = os.path.join(BASE, 'fonts')

SEASONS = {
    1: ('آغاز رؤیا و تولد مسیر', 'فصل اول', 'از یک سؤال در شب تا نامی که روی اینترنت نوشته شد. احمد زبان ماشین را می‌آموزد، ذهن مهندسی‌اش بیدار می‌شود و خراسان دیجیتال متولد می‌شود.'),
    2: ('جنگ با محدودیت‌ها و ساختن امپراتوری دیجیتال', 'فصل دوم', 'کیف پولی که اعتماد را ثبت می‌کند، شبکه‌هایی که دره‌ها را به هم وصل می‌کنند، کاربان که حق کارگر را دیدنی می‌کند، و امپراتوری کوچکی روی ابرها.'),
    3: ('سقوط، بازسازی و آینده‌ای که هنوز نوشته نشده است', 'فصل سوم', 'سیستمی که خاموش می‌شود، درهایی که باز نمی‌شوند، حسابی که باید درست شود، بهای استقلال، و شجاعت شروع دوباره تا قله‌ای که از آن، آینده دیده می‌شود.'),
}

FA = str.maketrans('0123456789', '۰۱۲۳۴۵۶۷۸۹')
def fa(n):
    return str(n).translate(FA)

def font_css():
    f = lambda name: 'file://' + os.path.join(FONTS, name)
    return f"""
@font-face{{font-family:'Vazirmatn';font-weight:300;src:url('{f('Vazirmatn-Light.ttf')}')}}
@font-face{{font-family:'Vazirmatn';font-weight:400;src:url('{f('Vazirmatn-Regular.ttf')}')}}
@font-face{{font-family:'Vazirmatn';font-weight:500;src:url('{f('Vazirmatn-Medium.ttf')}')}}
@font-face{{font-family:'Vazirmatn';font-weight:700;src:url('{f('Vazirmatn-Bold.ttf')}')}}
@font-face{{font-family:'Vazirmatn';font-weight:800;src:url('{f('Vazirmatn-ExtraBold.ttf')}')}}
@font-face{{font-family:'Vazirmatn';font-weight:900;src:url('{f('Vazirmatn-Black.ttf')}')}}
@font-face{{font-family:'Naskh';font-weight:400;src:url('{f('noto-naskh-arabic-arabic-400-normal.woff2')}')}}
@font-face{{font-family:'Naskh';font-weight:700;src:url('{f('noto-naskh-arabic-arabic-700-normal.woff2')}')}}
@font-face{{font-family:'Cinzel';font-weight:400;src:url('{f('cinzel-latin-400-normal.woff2')}')}}
@font-face{{font-family:'Cinzel';font-weight:700;src:url('{f('cinzel-latin-700-normal.woff2')}')}}
"""

def load_episode(n):
    path = os.path.join(BASE, 'episodes', f'EP_{n:02d}.txt')
    raw = open(path, encoding='utf-8').read()
    head, body = raw.split('\n---\n', 1)
    meta = {}
    for line in head.strip().split('\n'):
        k, v = line.split(':', 1)
        meta[k.strip()] = v.strip()
    meta['n'] = n
    meta['season'] = int(meta['season'])
    meta['body'] = body
    return meta

def all_episodes():
    return [load_episode(i) for i in range(1, 17)]

ORDINALS = ['یکم','دوم','سوم','چهارم','پنجم','ششم','هفتم','هشتم','نهم','دهم','یازدهم','دوازدهم','سیزدهم','چهاردهم','پانزدهم','شانزدهم','هفدهم','هجدهم','نوزدهم','بیستم']

def body_to_html(body, skip_sections=()):
    """Convert simple markup to HTML. Renumbers scenes sequentially."""
    out = []
    scene = 0
    skipping = False
    for line in body.split('\n'):
        s = line.strip()
        if not s:
            continue
        if s.startswith('## '):
            title = s[3:].strip()
            skipping = title in skip_sections
            if skipping:
                continue
            out.append(f'<h2>{html.escape(title)}</h2>')
            continue
        if skipping:
            continue
        if s.startswith('### '):
            t = s[4:].strip()
            m = re.match(r'صحنه[‌\s]*ی?[^:]*:\s*(.*)', t)
            if m:
                name = m.group(1)
                label = f'صحنه‌ی {ORDINALS[scene]}'
                scene += 1
                out.append(f'<h3><span class="sl">{label}</span>{html.escape(name)}</h3>')
            else:
                out.append(f'<h3>{html.escape(t)}</h3>')
            continue
        if s.startswith('> '):
            txt = s[2:]
            txt = re.sub(r'^راوی:\s*', '', txt)
            out.append(f'<blockquote class="narr"><span class="who">راوی</span>{html.escape(txt)}</blockquote>')
            continue
        if s.startswith('— '):
            txt = s[2:]
            m = re.match(r'([^:]{1,40}):\s*(.*)', txt)
            if m:
                out.append(f'<p class="dlg"><b>{html.escape(m.group(1))}</b><span>{html.escape(m.group(2))}</span></p>')
            else:
                out.append(f'<p class="dlg"><span>{html.escape(txt)}</span></p>')
            continue
        if s.startswith('یادداشت:'):
            out.append(f'<p class="note">{html.escape(s)}</p>')
            continue
        out.append(f'<p>{html.escape(s)}</p>')
    return '\n'.join(out)
