import os, subprocess, html, re, sys
from pypdf import PdfReader
from common import BASE, font_css, all_episodes, fa, SEASONS, body_to_html
from scenes import scene_svg

OUT = os.path.join(BASE, 'out', 'THE_LAST_CODE_OF_KHORASAN')
TMP = os.path.join(BASE, 'tmp_pdf')
os.makedirs(TMP, exist_ok=True)
from PIL import Image
IMG = os.path.join(TMP, 'img'); os.makedirs(IMG, exist_ok=True)
def _jpg(src, name):
    dst = os.path.join(IMG, name)
    Image.open(src).convert('RGB').resize((1500, 2250), Image.LANCZOS).save(dst, 'JPEG', quality=82, optimize=True)
    return 'file://' + dst
POST = lambda n: _jpg(os.path.join(OUT, 'Posters', f'Poster_{n:02d}.png'), f'p{n:02d}.jpg')
COVER = _jpg(os.path.join(OUT, 'Main_Cover.png'), 'cover.jpg')

CSS = font_css() + '''
@page{size:160mm 240mm;margin:20mm 18mm 22mm 18mm;
  @bottom-center{content:counter(page, persian);font-family:Vazirmatn;font-size:9pt;color:#8a6a22}
  @top-center{content:"آخرین کُد خراسان";font-family:Vazirmatn;font-size:7.5pt;color:#9bb8ad;letter-spacing:.5pt}}
@page full{margin:0;@bottom-center{content:none}@top-center{content:none}}
@page plain{@top-center{content:none}}
*{box-sizing:border-box}
html{direction:rtl}
body{margin:0;font-family:Vazirmatn;font-weight:400;font-size:10.8pt;line-height:2;color:#1b1b18;text-align:justify}
.full{page:full;width:160mm;height:240mm;break-after:page;position:relative;overflow:hidden;background:#000}
.full img.bleed{width:160mm;height:240mm;object-fit:cover;display:block}
.dark{background:radial-gradient(ellipse at 50% 40%,#0b3a2a 0%,#03120c 55%,#000 100%);color:#efe6c8;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;padding:24mm}
.dark .k{font-family:Cinzel;font-weight:700;letter-spacing:4pt;color:#d9b45a;font-size:11pt}
.dark h1{font-family:Vazirmatn;font-weight:900;font-size:34pt;line-height:1.35;margin:8mm 0 4mm;color:#e9c977}
.dark .s{font-family:Vazirmatn;color:#38d39f;font-size:12pt;font-weight:600}
.dark p{font-family:Vazirmatn;font-size:12.5pt;line-height:2;color:#e7dfc6;max-width:105mm;text-align:center}
.orn{width:60mm;height:1px;background:linear-gradient(90deg,transparent,#d9b45a,transparent);margin:6mm auto}
.sec{break-before:page}
.plainpage{page:plain}
h1.chap{font-family:Vazirmatn;font-weight:800;font-size:22pt;color:#0b5a40;margin:0 0 2mm;text-align:right;line-height:1.4}
.chapk{font-family:Vazirmatn;font-weight:600;font-size:9.5pt;color:#8a6a22;letter-spacing:.5pt}
.cine{font-family:Vazirmatn;font-weight:500;font-size:12pt;color:#555;margin-bottom:4mm}
.taglinebox{border-right:3pt solid #d9b45a;background:#f6f1e1;padding:3mm 5mm;margin:5mm 0 6mm;font-size:12.5pt;color:#3a2f12;font-weight:700}
.intro{font-size:11pt;color:#333;background:#eef6f2;border-radius:2mm;padding:4mm 5mm;margin-bottom:6mm}
h2{font-family:Vazirmatn;font-weight:800;font-size:14pt;color:#0b5a40;margin:9mm 0 3mm;padding-bottom:1.5mm;border-bottom:1px solid #d9b45a;break-after:avoid}
h3{font-family:Vazirmatn;font-weight:700;font-size:11.5pt;color:#1f3d33;margin:6mm 0 2mm;break-after:avoid}
h3 .sl{display:inline-block;font-weight:600;font-size:8.5pt;color:#fff;background:#0b5a40;border-radius:1mm;padding:0 2mm;margin-left:2.5mm}
p{margin:0 0 2.6mm;orphans:2;widows:2}
p.dlg{padding-right:4mm;border-right:1.5pt solid #c9e6da}
p.dlg b{font-family:Vazirmatn;font-weight:700;color:#0b5a40;font-size:10pt;margin-left:2mm}
p.dlg b:after{content:":"}
blockquote.narr{margin:4mm 6mm;padding:3mm 5mm;background:#0b1a14;color:#efe6c8;border-radius:1.5mm;font-size:11pt;line-height:1.9;break-inside:avoid}
blockquote.narr .who{display:block;font-family:Vazirmatn;font-size:8pt;color:#d9b45a;letter-spacing:1pt;margin-bottom:1mm}
p.note{font-family:Vazirmatn;font-size:8.5pt;color:#6b6b6b;background:#f3f3f0;padding:2mm 3mm;border-radius:1mm}
.toc h1,.front h1{font-family:Vazirmatn;font-weight:800;font-size:20pt;color:#0b5a40;margin:0 0 6mm}
.toc .row{display:flex;justify-content:space-between;align-items:baseline;font-family:Vazirmatn;font-size:10.5pt;margin:1.2mm 0;border-bottom:1px dotted #cbb67a}
.toc .row.season{font-weight:800;color:#8a6a22;margin-top:5mm;border-bottom:none}
.toc .num{color:#8a6a22;font-weight:700}
.front p{font-size:11.5pt}
.ded{display:flex;align-items:center;justify-content:center;height:190mm;text-align:center;font-size:13pt;line-height:2.3;color:#0b3a2a}
.copy{font-family:Vazirmatn;font-size:9pt;line-height:1.9;color:#444;padding-top:90mm}
.art{width:160mm;height:240mm}
.art .cap{position:absolute;bottom:14mm;left:14mm;right:14mm;text-align:center;font-family:Vazirmatn;font-size:11pt;line-height:1.9;color:#efe6c8;background:rgba(0,0,0,.6);padding:4mm;border:1px solid rgba(217,180,90,.5)}
.art .cap b{display:block;font-family:Vazirmatn;color:#d9b45a;font-size:9pt;margin-bottom:1mm}
.marker{font-size:2pt;color:rgba(0,0,0,0);line-height:1;height:2pt;direction:ltr}
.end{font-family:Vazirmatn;text-align:center;color:#8a6a22;margin-top:10mm;font-size:10pt}
'''

def section_text(body, name):
    m = re.search(r'## ' + re.escape(name) + r'\n(.*?)(?=\n## |\Z)', body, re.S)
    return m.group(1).strip() if m else ''

def episode_block(ep, marker=False):
    n = ep['n']; s = ep['season']
    sname, slabel, _ = SEASONS[s]
    final = section_text(ep['body'], 'صحنه‌ی نهایی')
    final_first = final.split('\n')[0] if final else ''
    mk = f'<div class="marker">@@EP{n:02d}@@</div>' if marker else ''
    return f'''
<div class="full"><img class="bleed" src="{POST(n)}"></div>
<div class="sec">{mk}
 <div class="chapk">{slabel}: {html.escape(sname)} · قسمت {fa(n)}</div>
 <h1 class="chap">{html.escape(ep['title'])}</h1>
 <div class="cine">{html.escape(ep['cine_title'])}</div>
 <div class="taglinebox">«{html.escape(ep['tagline'])}»</div>
 <div class="intro"><b>معرفی قسمت: </b>{html.escape(ep['intro'])}</div>
 {body_to_html(ep['body'])}
 <div class="end">— پایان قسمت {fa(n)} —</div>
</div>
<div class="full art">{scene_svg(n)}<div class="cap"><b>تصویر تکمیلی · صحنه‌ی نهایی قسمت {fa(n)}</b>{html.escape(final_first[:260])}{'…' if len(final_first) > 260 else ''}</div></div>
'''

def doc(body):
    return f'<!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8"><style>{CSS}</style></head><body>{body}</body></html>'

def to_pdf(html_text, name, out_pdf):
    hp = os.path.join(TMP, name + '.html')
    open(hp, 'w', encoding='utf-8').write(html_text)
    subprocess.run(['google-chrome', '--headless=new', '--no-sandbox', '--disable-gpu', '--allow-file-access-from-files',
                    '--no-pdf-header-footer', '--virtual-time-budget=20000', f'--print-to-pdf={out_pdf}', 'file://' + hp],
                   check=True, capture_output=True, timeout=600)

def build_episodes(eps):
    for ep in eps:
        n = ep['n']; s = ep['season']
        sname, slabel, _ = SEASONS[s]
        head = f'''<div class="full dark"><div class="k">THE LAST CODE OF KHORASAN</div><h1>آخرین کُد خراسان</h1>
        <div class="orn"></div><div class="s">{slabel}: {html.escape(sname)}</div><div class="s" style="color:#e9c977;margin-top:3mm">قسمت {fa(n)}</div>
        <h1 style="font-size:26pt">{html.escape(ep['title'])}</h1><p>«{html.escape(ep['tagline'])}»</p><div class="orn"></div>
        <p style="font-size:10pt;color:#bfae7a">نویسنده: وکیل احمد حیدری</p></div>'''
        # poster first, then series/episode title page, then story
        blk = episode_block(ep)
        poster, rest = blk.split('</div>', 1)
        html_text = doc(poster + '</div>' + head + rest)
        d = os.path.join(OUT, f'Season_{s:02d}'); os.makedirs(d, exist_ok=True)
        out = os.path.join(d, f'Episode_{n:02d}.pdf')
        to_pdf(html_text, f'ep{n:02d}', out)
        print('episode', n, len(PdfReader(out).pages), 'pages')

def front_sections():
    raw = open(os.path.join(BASE, 'frontmatter.txt'), encoding='utf-8').read()
    secs = {}
    for part in raw.split('## ')[1:]:
        t, b = part.split('\n', 1); secs[t.strip()] = b.strip()
    return secs

def paras(t):
    return ''.join(f'<p>{html.escape(l)}</p>' for l in t.split('\n') if l.strip())

def build_book(eps, pages=None):
    fs = front_sections()
    pages = pages or {}
    P = lambda k: fa(pages.get(k, '')) if pages else '—'
    toc = ['<div class="sec toc plainpage"><h1>فهرست مطالب</h1>']
    for k, lab in [('pre', 'پیشگفتار'), ('char', 'معرفی شخصیت اصلی'), ('world', 'معرفی جهان داستان')]:
        toc.append(f'<div class="row"><span>{lab}</span><span class="num">{P(k)}</span></div>')
    for s in (1, 2, 3):
        toc.append(f'<div class="row season"><span>{SEASONS[s][1]}: {html.escape(SEASONS[s][0])}</span><span class="num">{P(f"S{s}")}</span></div>')
        for ep in eps:
            if ep['season'] == s:
                toc.append(f'<div class="row"><span>قسمت {fa(ep["n"])}: {html.escape(ep["title"])}</span><span class="num">{P(f"EP{ep["n"]:02d}")}</span></div>')
    toc.append(f'<div class="row season"><span>پایان‌بندی بزرگ مجموعه</span><span class="num">{P("endx")}</span></div>')
    toc.append(f'<div class="row"><span>یادداشت نویسنده</span><span class="num">{P("note")}</span></div></div>')

    mk = lambda k: f'<div class="marker">@@{k}@@</div>'
    parts = [f'<div class="full"><img class="bleed" src="{COVER}"></div>',
             '''<div class="full dark"><div class="k">THE LAST CODE OF KHORASAN</div><h1 style="font-size:40pt">آخرین کُد خراسان</h1><div class="orn"></div>
             <p>کتاب سینمایی در سه فصل و شانزده قسمت</p><div class="orn"></div><div class="s" style="color:#e9c977;font-size:14pt">وکیل احمد حیدری</div></div>''',
             f'<div class="sec plainpage copy front"><h1 style="font-size:13pt">حقوق اثر</h1>{paras(fs["حقوق اثر"])}</div>',
             f'<div class="sec plainpage"><div class="ded"><div>{"<br>".join(html.escape(l) for l in fs["تقدیم"].split(chr(10)))}</div></div></div>',
             f'<div class="sec front">{mk("pre")}<h1>پیشگفتار</h1>{paras(fs["پیشگفتار"])}</div>',
             f'<div class="sec front">{mk("char")}<h1>معرفی شخصیت اصلی</h1>{paras(fs["معرفی شخصیت اصلی"])}</div>',
             f'<div class="sec front">{mk("world")}<h1>معرفی جهان داستان</h1>{paras(fs["معرفی جهان داستان"])}</div>',
             ''.join(toc)]
    for s in (1, 2, 3):
        sname, slabel, sintro = SEASONS[s]
        eplist = '<br>'.join(f'قسمت {fa(e["n"])}: {html.escape(e["title"])}' for e in eps if e['season'] == s)
        parts.append(f'''<div class="full dark">{mk(f"S{s}")}<div class="k">SEASON {s}</div><h1>{slabel}</h1><div class="s" style="font-size:15pt">{html.escape(sname)}</div>
        <div class="orn"></div><p>{html.escape(sintro)}</p><div class="orn"></div><p style="font-family:Vazirmatn;font-size:10pt;color:#d9b45a">{eplist}</p></div>''')
        for ep in eps:
            if ep['season'] == s:
                parts.append(episode_block(ep, marker=True))
    parts.append(f'<div class="sec front">{mk("endx")}<h1>پایان‌بندی بزرگ مجموعه</h1>{paras(fs["پایان‌بندی بزرگ مجموعه"])}</div>')
    parts.append(f'<div class="sec front">{mk("note")}<h1>یادداشت نویسنده</h1>{paras(fs["یادداشت نویسنده"])}</div>')
    parts.append('''<div class="full dark"><div class="k">THE LAST CODE OF KHORASAN</div><h1>آخرین کُد خراسان</h1><div class="orn"></div><p>داستان ادامه دارد.</p></div>''')
    out = os.path.join(OUT, 'Complete_Book.pdf')
    to_pdf(doc(''.join(parts)), 'book', out)
    return out

def find_markers(pdf):
    r = PdfReader(pdf); found = {}
    for i, pg in enumerate(r.pages):
        for m in re.findall(r'(pre|char|world|endx|note|S\d|EP\d\d)@@', pg.extract_text() or ''):
            found.setdefault(m, i + 1)
    return found

if __name__ == '__main__':
    eps = all_episodes()
    what = sys.argv[1] if len(sys.argv) > 1 else 'all'
    if what in ('all', 'eps'):
        build_episodes(eps)
    if what in ('all', 'book'):
        out = build_book(eps)
        pages = find_markers(out)
        print('markers', pages)
        out = build_book(eps, pages)
        p2 = find_markers(out)
        print('pages', len(PdfReader(out).pages), 'stable', p2 == pages)
