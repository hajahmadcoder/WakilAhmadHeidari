# CLAUDE.md — آخرین کُد خراسان / THE LAST CODE OF KHORASAN

Author and main character: «وکیل احمد حیدری» (Wakil Ahmad Heidari). Never shorten to «احمد».

The project was delivered as 4 ZIP parts (each under 25 MB, for GitHub web upload):
- Part1_Site_CloudflarePages.zip — the complete static website (index.html at root,
  episodes/, downloads/pdf/ with Complete_Book.pdf + Episode_01..16.pdf, assets/, _headers, _redirects, 404.html).
- Part2_Posters_PNG_1.zip, Part3_Posters_PNG_2.zip — print-quality PNGs (Main_Cover, Banner, Poster_01..16, 2400x3600).
- Part4_Source_Texts.zip — this file, episode texts, front matter, quality report, build scripts.

## Task for Claude Code
1. In the GitHub repo, unzip Part1 into the repo ROOT (index.html must be at root). Delete the ZIP files after extracting.
2. Put Part2 + Part3 contents in `print/` and Part4 `source/` in `source/` — these are NOT needed for the site;
   if they should not be public on Pages, keep them in a separate private repo or branch instead.
3. Cloudflare Pages > Create > Pages > Connect to Git > this repo.
   Framework preset: None. Build command: (empty). Build output directory: `/`.
   Project name: wakilahmadheidari  →  https://wakilahmadheidari.pages.dev
4. Verify: home page, /start, /downloads.html, all 16 episode pages, every PDF link returns 200, RTL Persian renders.

## Rules
- No single file may exceed 25 MiB (Cloudflare Pages limit). Largest file now: Complete_Book.pdf ≈ 6.4 MB.
- Do not rewrite the story text; fix only real bugs. Keep the emerald/gold/black design and Vazirmatn font.
- Never put tokens, keys or account IDs in files or chat. No emoji.
- Hawala in 34 provinces, payment cards, licensing, other-country top-up and full automation are goals,
  never present them as active services.
